// eslint-disable-next-line no-unused-vars
import React, { useEffect, useState } from "react";

export default function Taskmanager() {
  const [task, setTask] = useState("");
  const [record, setRecord] = useState([]);
  const [edit, setEdit] = useState(null);
  const [message, setMessage] = useState(null);
  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("TaskData")) || [];
    setRecord(data);
  }, []);
  useEffect(() => {
    if (message) {
      setTimeout(() => {
        setMessage(null);
      }, 1000);
    }
  }, [message]);
  const handleAdd = () => {
    const Obj = { id: record.length+1, task, status: "Pending" };
    const oldData = JSON.parse(localStorage.getItem("TaskData")) || [];
    if (edit) {
      let singData = record.find((item) => item.id == edit);
      singData.id = edit;
      singData.task = task;
      localStorage.setItem("TaskData", JSON.stringify(record));
      setEdit(null);
      setTask("");
    } else {
      oldData.push(Obj);
      setRecord(oldData);
      localStorage.setItem("TaskData", JSON.stringify(oldData));
      setTask("");
    }
  };
  const handleEdit = (id) => {
    let editData = record.find((item) => item.id == id);
    setTask(editData.task); 
    setEdit(id);
  };

  const handleDelete = (id) => {
    let deleteData = record.filter((item) => item.id != id);
    setRecord(deleteData);
    localStorage.setItem("TaskData", JSON.stringify(deleteData));
  };
  const handleStatus = (id) => {
    let statusData = record.find((item) => item.id == id);
    statusData.status = "Complate";
    localStorage.setItem("TaskData", JSON.stringify(record));
  
    setMessage("Task Complate");
  };
  return (
    <>
      <center>
        <br />
        <h1>Task Manager</h1> <br />
        <br />
        <input
          type="text"
          placeholder="Enter Task"
          value={task}
          onChange={(e) => setTask(e.target.value)}
        />
        <button id="bt1" onClick={handleAdd}>
          {edit ? "Update Task" : "Add Task"}
        </button>
        <br />
        <br />
        <table border={2} width={"80%"}>
          <thead>
            <tr>
              <th>Id</th>
              <th>Task</th>
              <th>Status</th>
              <th colSpan={3}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {record
              ? record.map((e, i) => {
                  return (
                    <tr key={i}>
                      <td>{e.id}</td>
                      <td>{e.task}</td>
                      <td>{e.status}</td>
                      <td>
                        <button id="bt2" onClick={() => handleEdit(e.id)}>
                          Edit
                        </button>
                        <button id="bt3" onClick={() => handleDelete(e.id)}>
                          Delete
                        </button>
                        <button id="bt4" onClick={() => handleStatus(e.id)}>
                          Complete
                        </button>
                      </td>
                    </tr>
                  );
                })
              : ""}
          </tbody>
        </table>
      </center>
    </>
  );
}
