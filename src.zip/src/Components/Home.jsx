// eslint-disable-next-line no-unused-vars
import React, { useState } from "react";

export default function Home() {
  const [item, setItem] = useState("");
  const [catagory, setCatagory] = useState("");
  const arrObj = [
    {
      item: "LG",
      price:"₹ 50,000",
      catagory: "Washing Machine",
      url: "https://pngimg.com/d/washing_machine_PNG15578.png",
    },
    {
      item: "godrej",
      url: "https://w7.pngwing.com/pngs/39/324/png-transparent-washing-machines-lg-electronics-home-appliance-washing-machine-electronics-clothes-dryer-vacuum-cleaner.png",
      price: "₹ 40,000",
      catagory: "Washing Machine"
    },
    {
      item: "Haier",
      url: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxASEhUQEBMWFhUVFRYWFRUVFRUVFhYVFRYYFxUVFRUYHSggGBolGxUVITIhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFxAQFy0lHR0tLS0tKy0tKy0tKy0tLS0tLS0rLS0tLS0tLS0rLSsrLS0tLS0rLS0tLS0tLS0tKy0rLf/AABEIAQgAvwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAMFBgcCAQj/xABNEAACAAMDBQsICAUBBwUAAAABAgADEQQSIQUGMUFREyIyYXFygZGhscEHFDNCUnOy0SMkQ2KCkrPCNKLS4fCDFRZTY5PD8QhEdKPi/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAECAwT/xAAgEQEBAAMAAwEBAQEBAAAAAAAAAQIRMRIhQQNRE2Ei/9oADAMBAAIRAxEAPwDUVzmD1MlAygkVvUOHFTCC5GVgwreVTrBDEj5xmlrR7LPmCS5IluQa6aA+sNY4x2aIsuRsrSbRRWokzZqbkh2MfOrScoj21/6bf1Rycp/fH/TP9cR7WUjTCFniT8qOOVR7XUn/AO45OVuNvyqPGBPN4982gHlT5ytxv/J/THJysfv9af0Q35tHvm0A3Xpys33utP6I5OVX+9+YeAj3zaF5tAW6bOVH2H87eBjg5SfYfzzP6oe82jw2aAew5yjM4/zzP6o5OUJn+M572gg2aPDZoY9hGt0zYOqvfHDWx9i/kX5QWbNHJs0BewLz2ODKpHMUdoAMF2W3uvBmOvE30i/zb4DkMI2eOTIgHtMWfKz+sgbjlHH8jUPaYNkZRlMaBqH2WqrdRis7lSHhOalGow2MA3fogVM6tUKK5ItAXgs8viBvL+RtHQYPlZQfXccbVN1vytp6DAuZRKQoEk5SlNhW6djCnbo7YLgVtkOc0p1tM2aMAZrgEHGo0wAgD8Givs0Kx+6fVbi0bKYCJrO7hP8A/ImeEQlpswVUYHhrUjYaxpHNerPkHOxk+htQJUGl4jfLTUwi3bpLIDK9QRUEY4RliTlcBZvIswYsNgYeuvaNWyLtm+w83l46iNGxiNsTlDlTm6rHu7LxwHUbT1f3hXhtPV/eIUM3dePshecLsMB3hxx5fHH1/wBoBsZ5yNkeecjZ2/2gS+OPr/tHl8bO2AbFG1cXbHJtXFAjTOLvhmfaFUVZlXZeIArAWx5tR2Dthprdo4OOjj5MYr863yw1y9LJCGZQS2u3EIVqzMVBvMuGkVroisZ7Z9eYuLLJlLMngK0wzC6y5JcXhLCS2Us11gSS2FRph6ObrRGt3GscC2E6CDyUMZ/mnnuluJlOm4T1Bc3C7pNUCjXAzEowJBu1aoi0SZwoCRNatDvlIpUDCmEBX0lmtLbewfKGzaG29ggOaigEhASBgKAVOyp0RjGdGW7XLtFoli0TFKz3CoN6BLLVWjBtIqBS7oxrAJNtvae22GWtX3+2MMybarROkWhmtNoEyWZJl0mTiGvmYpl4OAt5rlDQ6I6NqmPk+XMSdNM82vcSd3tF5lMssooXuUqV0CuECvBtrWr7/wDN/eG2tI9v+aMDs7T5zSg0x1Rmlyy+6TDw2AvkMxJNGGgUw0aYuHkzmlZ08NeQtJlP9JWpuMVZhVF3pLGmmmippWAZYWdaQ1oG0nkqe6J/M+1Es8uppdvAGuGNCQDy9kUG3Z1yJVpFkZXreloXoLivNFZa4mp4yBQVFYuOaj0tNPalkdRr8oE4+rEHndwpnv5nhEXb/RSeae8xKZ28KZ79/wBsRdu9FJ5viY0ib2hGTeq22vYYuWbLfV04i/xk+MVB/Rpyt3xac12+g5HbwPjCy4Imqx5WIGZbbeXdZchLqtRWckBhU46anC7iBpZvZ3/kiflIvLvy5IQ4zKE1UVpRd8atTHZjTGlYhSfvR5egVpk2poiUrgTMIqNWAQ0h0Mdenr7YAdvR4WhusNTb+F1gNtVJryEEU17YAedu8d8Nz5lFJqRT2VLHoUA16oZAcVvMGGGhbtMeWHSYCR9qlvNSbJV5hMyU8tb0sBQ7CgY70YCoP4euq525trapE/Kd033o0xTwpUxFCTJTjUQy9oi42mzh8TeqCpFHZRVWDDAGmkbNENWyYbrNS41AtZbFbwAoL10i9sAOAphDhysc8nWTZzWtJ4UhJdd9oDFgVoK6cGPZGu2GUbq3hMBAXhTDUnjuGhNdOGMMJk5SKaVOPqnHqr01gpLGgNQADtCoD13YQt2Im4gjHQdGB0ajqMYpnujC12oVIW9Ke6QSxJkLvrwUjehjWrDha6YbOU+8ewdwgSfkuQzX2loWOlmWrGgoN8cYBLphdjnzJaOEQ78y9Ie8NzbdFZaLdpUAGtdOA0ke+ckIi4KZc9pyqXQXWYS6nfHR9EgpT1dMbn5hKGhAOTCPdzQbOSvzhq82ELZZpS6gdhQ1W+rKBhS7dbfaNFNQ0xafJ/ZZq2kEy3F6zTEJmKbga+rKu27dVTQ0xvRpbNLrWq9a0htpkranWICudvQ1ryTZnmpaJqAzEoQSxAqNBK1oSNRIwiayDaAtpltUGgfXtWIh3kE1JXt8I6S3olLp0aAAYE7PZ3cOb79+5YjLf6KTzfExKZ3cOb79u5YjcoD6GRzPExcK9oV/Rryt3xYsz6sk1R6hDnkagp2DrivzB9GnKe+LHmL/AO4G1F+KFeDHp605akoaG9XiX5w1Ly4rcGVNPQg73j3KWRixqI7sUh0wKxBirPNmPwZTdJHhWD0ybaD6gHK39oVkt5TGkSK5eXWvbAqa+gxkaf8AdHTWPf8AYU72k7YN/wB4JWuvZHhzjs40kwK1j/UblPJLy5LzCwJVScNFKccVxre/F1RaMrZfs8yS8pWNXW6MDTHj1RSmYQ4jLXw+1vmbewQ01tme12D5Qyf8wgaZapY0uo6RAkW1rme0Yba0zPbb8xgI2+V7a9YjpbQp0EHkIhg+05vaPWYbZztPXHBaPL0BPTHJhVjyAFHJj2OYAUdSRvh090cQRYKbotRUY4dB2QGmc7uHN983csR+Uh9DI93+4wfnd6Sb75vhWAcp+hke7/c0VBe0POH0SdPfE7mPwpnN8RTxiGtC/QSzy94ibzE4czm+IhXgx6tDpA8xP8rBzrA8xYhYCYkCzFEHTRAk2AgUxRAzwYyVqagACrMxoqgaSxOgRUM4M71l1SykjbOODt7sfZjj4R4sRDLSYyhaZUj0zUb/AIa76Z0jQvSRxAxVsq54BKhAsvi9LN6fVXppFNtuVJjk0JFdhxPTEW0NcxTWUc5JszWx43Yk9CjAdZiJmW6YdLHsEMGFcJ1QK1Hfncz2jHq2+aNDmG2kPsjhJTNUKK000gP0lrJnPapfrXhsaLHk3PGS9BNBlnbpXr1dMUNlIwII5cI8hFcZWwS5oYAggg6CMQY7rGV5IyzOs53hquuWeCdtPZPGOmsaBkjK8q0LelnEcJDwlPHtHHogZ3HSUrHkcho9rDS9h6xcMdPcYYh6x8MdPcYAms7vSzvfH4FgHKXoZHu/3NB2d3pZ3vj8CxH28/QyeZ+4xUF7XdpH1aX094iYzD4czmnvT5xE2r+Fl8rftiXzF4b8j98r5wrwTq3PA82H3MDTTGbQLNgKcQAWYhVUEsxwCgaSYLmmM3z4y/ujeayTvFO/bUzDSeNVOAGs46BhUSFzrzoM6suXVZKnAa3bUz8ewaFG0nGj2qaWNTBdpaAJpxprMUqGLpJoBUx3JsMxtVBx+EXjNHMmbaG3ylEFLzMMWOmlPDQNdTFvzh8n1UEyy03RRQoxwmDl1NFTGfSud+MpsVhRDV0vdPhoi42LJAaUJskBk10GKnYwGiIi0SGltcmoyMPVYUPRt6IVgytOsr7pIe6dY0qw2MNca61xlbtLvZCNQ6okM28jJaxMkNKVjLAdCQKgMaFL2rRUdMCnPSzzVO62cpM2yzvT0HRBeY+Xrk5gcBMI6xorCsthT1VbznzRMtS8qtAbjynqaPQkUJxAIB06Cp4oz+ahU0II5Y+oM8LPImWSbaGoCUUHjdWBTprh0xhmclhUE1GB16wa0J6dMZ2bjaZauqp5EO2S0vKcTJbXWGg94I1jijydLKEq3/kbRDbCM2jSshZYW0JeGDCgddh2jiOo/KJUGMqyVlBpEwTF1YMPaU6R8uOkabZbQrqroaqwBB4jAyyx0Kh6x8MdPcYHBgix8MdPcYaU1nb6af779ixHWs/QyuafiMSOd3pp/vR+msRc8/Qy+Q/FFQXtE2g/VpfK37Yl8yjRm5JnfJiDnN9Ag428Il80moT/AKnfJhXgnVud4FmvHjzYGmzIhaAz0y35vIN00mTKqp1gU3zDjAwHGYy0igx0nT4DoHbU64l868pecWpjXeS96v4Tgelqt+GIKfMioIGtDxaMwcnygWtcxb7qbtnlkVBmHTNYbF0Aba8RipWSS1onrJTWaf1HoAMbLkLJsuQJaKBhri8YnPLXorJlS0WZaTFxYkk8sEy85b2uLBb8miYlaRQ8sZKaWSVi5qs7uJ+bbZU4XZqK67GAMVTLeaMp99ZGun2GNVPNOkRzImzF0wQtvI1w9aLaiW/Js6S1JiEd3XB2S3pRgdBx+cXFspilHAYbGAI7YEtc+ymh3JQBqGFTyRUyF9icp5wbpJlyQaqDfc6mKjejjAFTykbIreUCJskkgA3a9Ipo7Yk8oNK3IuALxoqgaBXSKcgMDCRjMVcQEXrYE6eSJpxSLTY763RwgCV4yPV6RSINTqi7pZws2msGlOURWMu2HcZo2TEWYvI1Qf5laMs59b4X4Ai3Zj5Q4VnY6N+nITvx1kHpMVGCslWvcp0uZqVhe5pwbsJiFWbjU1MF2AVmL09xgJTBuTPSL0/CYbFNZ3enn+9H6axEzfRJ+LviWzu9PaPej9NYiJnok5W7xFQZdrtz9CvK3hErm01Cf9T/ALUQ59EvK3hEjkJ6E/j/AO38oLwosbzYistW7c5Mx60opodhOAPbXoh550VfPa00kUGth0jZ2xClB3XSdpJ8B3V6YFnzY4ebqgK0ztHXFNJFx8m9lRDaLZNwSWRLU6d82+YAazS51mLz/t6Q4qgPKXNR+WgjM8hy582z3ZYIQzCSab29QBtGLGir1DRE3ZshzFIuOa8ZAHUK98a4T0wzvtbly/aF9HPansvR1/mx7YOsuccmYwW2Lc++lSleMaRETYszLbMW9LKHivj5CAcq5FttnFZ0pgvtDFfzLURXpPtd7XkqTMW9JZXU6CpB7oqOV8kstSIgbLPdWrLZlPEaRacnZbdism0APeBulaF8BU70acKwa0VU+baGQm9oGmIXKWUqmo6Bsi9ZfyWJp3nBAwpoPHGf5UyXMSZRgQNuqFV46+upFrcS6sSd9UDk+Zp1xpeZ2TxNs0xnpfdg3NCgKteIgHrjPMjWbzickqm8UXjx6wD/AJqEbTJyf5rZC2h3H+CIuXxWmaixP5ygIwacNBrhX+2yInyiZPuWbJ82nCSehPNcOo/+xou2TpJNoRmGCVmVGu4K0iL8stl3KwZOlnSC4PRLRT2iFnVfmyQQjChRm2adkWeXkSnOkoteWlD2gxOZIH0q9PwmKtme9bKnEXH87RasjemT8XwmBhepjO/09o94v6SxDv6JeVvCJjO/+ItHvE/SWIdvRLyt4RcLLten0Y5W8IKyU1Cen9sCfZjlbwh6wHT0+EF4SSeZFMz+tBCp+Lt/wRaneKVn+d4p4wO2JVj1S2mQHaWqeiHS0DzTjCbRqmY1Wycg9kzP1HPiYkENIg/JlbhuDSj6rt1NRu8sIsVqlXTxHQY6cL6jjzn/AKq15p5SoQCYvqsGHEYx/J9p3NgWw11OinLFzyVlubPT6vRZY4VofCWu24Dwz2ceqI/THftp+WevSq+UDIln85vSSENBuiKQovHGopoNKV5Y6zZm2aQQwsbO4NQ6gsajWDEzPzgyfLJCENStXbfFzpZiddTEg+WHSSJlFQzBSQjAKWqMZj14MtRiT8xWvetJ9b3tVLJbVZ5xCEIZz3FPqg0JXkqTFazhmedObtFkShUtqY6C3GNQ24xY7fZ1WSE31wqxaZwA5atWrStwsToFW4IwqQ7mpmw9pKO4K2ZCpQMMZpGhmGzZyw9yeyktqM8nuaE8TxPmLdklb5vAG9ibo4m7qxYc4c5Zc6YZcoqyoKFeQ0rUY0qNsWXL+VJUuWZCawVNK4A6cRrjKLJm9NW2IZBvI5INdKgiprtxAoeSu2Mtb9tbZPS3ZDs18lroW/vABeNVU1c74nGpUdMU/wD9QlqG72SzA4ypLuR7xlUE/wDSaNUyBZVFGHBUC7xqNB/E1SOILHzx5SMsi2ZRnzlNUDbkhw4Mre1FDiC15vxRFaYzSsiPI6H+d0cwlL/maPqyc5/jMW7II+nT8XwNFZzalXbNKG1Q35t94xac3B9Yl/i+BoGV6k88P4i0e8T9JYhm9EvObwiZzw/iLR7yX+ksQzeiXnN+2Licu179mOVvCHLHr6fCG/sxzm8I7smvp8ILwj7mKxnlKVrO5OlRUcoIw74s7CIrLNl3SW6bVPdEnOslJht4cZSMDpGB5RHDCE3W/wAl2UJKWk2a0g7naAAGFb0ualSjjoLgjXUch2GdmrNu1lzFmIdBKk/zJUk/hEfOFnnvLZZktiroysjDSrKQVYcYIBjeMiZ72afIWekwWebSk+XfCjdAMdzTfVU6qqcMARQxeFvIz/TGdolMhzl3rGUy6SrSrQ2ji3LTD2WGSYgW07pRRgsvdFQU2o90GDsm5WFopSauOi8swHrSb8omJWQy1GvgciY9DvVh0ERp5a6xmNvFAsGS5ZdZkmzziARdmTdzly6/jLKxrsqdgi0yrIzOGYGdOw03nCHi3TBdeN1KeywiwysgitXcnafWPEXOJHESYkpaSpQoKKBqicv02vH8r9QVnzYEx91thvkG8JY4AO1q4seM92EcZx5xCSu5yaA6KimHIOuDcqZRYgqgw2+H+dsULKklmagFScMMSeXaeLHkEKTfTysx9Yo97W0xqkkmtK8ZOjl4q47IteS7AVFG4TAF6aVRsAgI9ZsQOKp2GGMj5E3KkxwDMpUA4rLB9ZvBRwtQpUxPTrRKskprRPa6F32+xYlsLzAaZjYAKNGA0CDLL5Bhh9qC8pOcHmFiZZZAnzqpLp6rEb5gNiKcOMrHzpuVMIuOd2VplutDT3qBwZaVqEljQvGdJJ1knVQCD80iNNZUPMFBynsH/nsjiTKLsqDSxCjpNI6tLgsaaBgOQa+nE9MTGaNjvzr50SxX8TYDsvdkI7dRe7MgCgDQAAOiJzNcfWZf4vgaIhBE1moPrUr8f6bQMZ0bnj/E2nny/wBJYhj6Jec37Ymc8f4m08+V+ksQp9EOc3csXCy7Xv2Y5zeEO2IYnp8Ia+zHObuWCMmjE9PhBeEfKwPOSJEpDUyVEBkOdeTjJtDD1X36nl0/PpiFIjUc78j7vJJUfSS6svGvrL4/+IzMrA2xu4GIgzJNvMiasy6HAO+QlgHXWpKmo5Ro7IHdIbgU3bNfOuxz8LLZ1l4C+t5Q+jC89KkV21GBOqLbLnuaNeujYu9Hbrp3n2THzDZbTMlOJkpmR10MpoR/bii8ZG8qNrli7aAswe2EUTe8KeztNb8mdw1xtPnz1pebpJ5NH+bNNIJlLXGvb4xRMjZ95Lm03W07kTpE1Ji9BYKV7Yt1mzzyMgr59ZuUPU9pMFsKY2pXzFnGAoNZPy/wcUPWTJCqaqMdbkV/KD49UVq3+VvI8sbya846llSnx/E4Ve2KjlnytWmfVLJLEhT67ETJlOIUur/NC3avxkaJl/LVjsC35z77Eog3zs20LpY/eOA2iMbznzmn26Zemb2WpJlygaha+sx9Z6a+qkAvfmsZkxmd2xZmJZjykx0LLBorQiyaxHZftAlruS8Jxj91D4nRyV4ok8qW5LOtTi54C7fvHYvfo5KXOms7F3NWJqSdZgtORzGiZt5O3GUAeEd83KdXQKDoit5qZK3Rt2cb1TveNhr5B38kXuWsSWd+O1ETmZ4rbJX4/wBN4hQIncyR9dk/6n6TwInYezy/ibTz5X6KxCn0Q5zdyxM55/xNp58n9FYhT6Ic9u5YuFl2uvsxzm7lgzIq1Y8h8IC+zHObuWJLN1azDzT3rBeEkzKjh5MSW5Rw0qIUhZ8nXGcZ5ZA3NjPlj6NjvgPUc/tOrjw2RrM2TEbbLICCCAQRQg4gg6QRAJdMMZIYdIt+cubTSSZkoEy9mkpxHaOPr2msOsNrLsHHkPOsNkQjcx6I8j0QATIibyfEDKcDSYOlZVVOCpY9QhwqutilViLy1nHKlVSTSZM0E+ovKfWPEOvVFXtuWJ80XWai+wuAPLrPSaRHw7SmP9OT5zOxdyWY4kn/ADsg/ImSWntjUIDvjt+6OPuh/I2QHnEM9VTqZuTYOPq2xerFZFRQqgADAARIyy06slmVFCqKACgA1AQUohKsdiGyKJ7McfXZX+p+m0QMWDMQfXZfI/wGA8ews9P4q08+T+isQp9EOe3csTme5K2qerCl/cnU7QEVCa7Khh0GII+iHPbuWKhZdrr7Mc5u5Yls1FrNPNbvWIj7Mc5u5YnMzBWc3Mb4khXhTqzblHLSoP3OOGlxDRGTJUBzpUS8yXAk5ICQFqswMUnLuaCNV5G8b2TwDyezGjT0iOnyoZb0xPKOTZsk0moV49KnkYYRHsI2m02cHSIr9uzasz4mWAdq1X4cDDXM/wCszMeRdp2Zsqu9dxxVUj4awx/uan/EfqX5QtH5xT48Ji7ys0JI4RduVgPhAiSsmRJEvFJagjXSp/McYNDzii2LJE+bwUIHtNvR0az0CLTkjNdEIZhujcYwHIviYsSSAIII0DVQYaqkaeWGi501KsjD1T1GHhJPF+ZfnHgWPaQJPCz4VvLtpXHDiEcXV29Q+dIV80pU02VNI5gDve8Z6h84sOYVPPFoPUfSa6uSK3Fl8nw+t/6b/tgPHsTnlJybelJaFGMs3X5jaD0NT8xihH0Q57fCsbVa7OsxGluKq6lTyEUMY7b5TSg1nfhSppGilQa49NAeQiHjVfpPezA9GOc3csT2Y4+nb3bfEkQH2f427kiwZi+nb3bfEkF4idXi7HDLDlY4cxm0DTVgKcIOmmApxhlUfOER88RIzoj58NNATlgOYkHTYEmQ0hHSGykEMIbIgBm5Ht2O6R5AHlI6Ydw7hHkdP4DuEAcwoUKAFChQoAUWjydD62fdP8SRV4tXk4H1p/ct8cuCqx7GkxnnlJyZdmJaVGD7x+coqp6VqPwCNDiPy/k4WizzJOsiqnY4xU9YHRWFK2ym4yD7Mc9vhSJ7Mg/TN7tviSIZlG46CGVzeB2mg0auDSJXM5qTW5jfEkVeMJ1er8cs8DbrHLTYhbqa8BzmjqZMgWbMgIzOaAJxgic8BTWhpDzTAzmHphgdzDI00cGO2jgwByY8j2PIAUet8u6PI9fTAHkKFCgDyFChQAotvk2H1iYf+Ue11+UVKLj5NB9NNP8Ayx2t/aCqw60KFChRLoZbn3k8ybSzKN5P342Xxwxy1NfxwPmu1Jjc096xec+cmbtZWYDfyvpF5AN+Py1NNoEUDIL0YniPesX8YZTWS17tHLToB3aOWnRJbFPNgaZNhl50MPMgJ1NmQLMeE7ww7QE5doZYx0xhpmhh4Y5MdS1LYICx+6C3dBknI1qfgyJvTLZR1sAID0AjyJ2Tmjbm+xu8bPL7gxPZBsnMO1nhPKUc5mPVdp2wj8b/ABVY9bSYu8nyen17RyhZfiW8IOl5g2YYtMmtxVQDsWvbAfhWcwo1OVmbYV+yLc6ZM7gadkGysgWNdFnlcpRSesisGz/zrHrw0VxgqVk6e3AkzW5styOsCNmlSVXBVC8gA7o7g2f+f/WRys2Lc2iQ3SUX4mEXfMzN97KrvNIvvQXQahVWuvWST2CLLCg2qYSFChQoSyIjMsq5FayTWIU7kxa42kKKiisdXEYUKHEZzcNSw7cFHbmI7fCDBMvJlqbgyJnSAnxkQoUCZhBEvNq2t6irz5g/ZegmXmbaDw5kteQM/fdhQoNq/wA4JlZjj157HmIF+ItBUrMmyjhNNfnOB8AEKFCPxn8GSc1bCuiSDzmd/iJg2RkqzJwJMpebLQdwhQoD1BYEewoUBlChQoAUKFCgBQoUKAFChQoAUKFCgD//2Q==",
      price: "₹ 55,000",
      catagory: "Washing Machine"
    },
    {
      item: "Panasonic",
      url: "https://images.rawpixel.com/image_png_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTEyL3Jhd3BpeGVsX29mZmljZV80N19waG90b19vZl9hX2dyYXlfbWV0YWxsaWNfd2FzaGluZ19tYWNoaW5lX25hdF9kZTFkNGFhNC0yMzMwLTQ1NGEtOWZjMS00Mjg5ZGYzNzBlNjdfMi5wbmc.png",
      price: "₹ 15,000",
      catagory: "Washing Machine"
    },
    {
      item: "Bosch",
      url:"https://d1pjg4o0tbonat.cloudfront.net/content/dam/comfee-aem/global/products/laundry/front-loading-washing-machine/kv1.png/jcr:content/renditions/cq5dam.compression.png",
      price: "₹ 1,20,000",
      catagory: "Washing Machine"
    },
    {
      item: "Whirlpool",
      url: "https://www.pngplay.com/wp-content/uploads/8/Laundry-Washing-Machine-PNG-Images-HD.png",
      price: "₹ 35,000",
      catagory: "Washing Machine"
    },
    {
      item: "Samsung",
      url: "https://png.pngtree.com/png-clipart/20210905/original/pngtree-silver-automatic-washing-machine-png-image_6695977.jpg",
      price: "₹ 30,000",
      catagory: "Washing Machine"
    },
    {
      item: "IFB",
      url: "https://www.ifbappliances.com/media/catalog/product/cache/ab27e2d12b7baa9faaaff0d7d3ddf1f2/s/e/senator-mbn-8.0kg-fv_3.png",
      price: "₹ 27,000",      
      catagory: "Washing Machine"

    },
    {
      item: "LG",
      url:"https://e7.pngegg.com/pngimages/596/605/png-clipart-direct-cool-refrigerator-auto-defrost-samsung-inverter-compressor-refrigerator-kitchen-electronics-thumbnail.png",
      price: "₹ 58,000",
      catagory: "freez"
    },
    {
      item: "Sony",
      url:"https://purepng.com/public/uploads/thumbnail//purepng.com-refrigeratorrefrigeratorfridgeiceboxrefrigeratoryfreezer-1701528368765vknfb.png",
      price: "₹ 70,000",
      catagory: "freez"
    },
    {
      item: "Whirpool",
      url:"https://p.kindpng.com/picc/s/171-1714066_image-for-samsung-bottom-freezer-and-french-doors.png",
      price: "₹ 45,000",
      catagory: "freez"
    },
    {
      item: "Samsung",
      url:"https://www.freepnglogos.com/uploads/fridge-png/fridge-bay-area-samsung-appliance-repair-the-appliance-repair-25.png",
      price: "₹ 22,500",
      catagory: "freez"
    },
    {
      item: "Haier",
      url:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEz6MKeWuFEA61wJcHHaOiVTkpTcNkUrYSjN3DsPqiyOuU_UbKENvv5lS5pJNoWH08aD4&usqp=CAU",
      price: "₹ 60,000",
      catagory: "freez"
    },
    {
      item: "Godrej",
      url:"https://png.pngtree.com/png-clipart/20240308/original/pngtree-3d-illustration-fridge-in-smart-home-set-png-image_14534992.png",
      price: "₹ 80,000",
      catagory: "freez"
    },
    {
      item:"LG",
      url:"https://png.pngtree.com/png-vector/20230408/ourmid/pngtree-led-tv-television-screen-vector-png-image_6673700.png",
      price: "₹ 1,60,000",
      catagory: "TV"
    },
    {
      item:"mi",
      url:"https://www.freeiconspng.com/thumbs/television-tv-png/television-png-tv-22.png",
      price: "₹ 51,000",
      catagory: "TV"
    },
    {
      item:"Sumsung",
      url:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkPiPLnK5WSH8LWK-YM3Em7p6P0KWhQdnfBg&s",
      price: "₹ 1,40,000",
      catagory: "TV"
    },
    {
      item:"Toshiba",
      url:"https://e7.pngegg.com/pngimages/895/35/png-clipart-led-backlit-lcd-aoc-international-television-set-1080p-led-tv-television-media.png",
      price: "₹ 28,800",
      catagory: "TV"
    },
    {
      item:"Acer",
      url:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzRVevgcn-jqY_E4DZrlTrLltIHhtFk8tsTqzZnqnRT2-llhktPhHI4dm8ltPOySIpd5Q&usqp=CAU",
      price: "₹ 38,000",
      catagory: "TV"
    },
  ];
  
  const data = arrObj.filter((e) => e.item.toLowerCase().includes(item.toLowerCase()) &&
      (catagory ? e.catagory.toLowerCase() === catagory.toLowerCase() : true)
  );
  return (
    <>
  <center>
    <br /><br /><br />
    <h1 style={{ color: "#333", marginBottom: "20px" }}>Searching Project</h1>
    <br />
    <input
      type="text"
      placeholder="Enter Item"
      onChange={(e) => setItem(e.target.value)}
    />
    <select
      onChange={(e) => setCatagory(e.target.value)}
      style={{padding: "10px",fontSize: "1.1rem",border: "2px solid #ddd",borderRadius: "5px",width: "200px",}}>
      <option value="">All Category</option>
      <option value="Washing Machine">Washing Machine</option>
      <option value="freez">freez</option>
      <option value="TV">TV</option>
    </select>
    <br />
    <br />
    {data &&
      data.map((e, i) => {
        return (
          <div id="b1" key={i}>
            <img style={{height:"290px",width:"100%",objectFit:"contain",borderRadius:"10px"}} src={e.url}  alt=""/>
            <p style={{fontSize:"30px",paddingTop:"10px",fontWeight:"bolder"}}>{e.item}</p>
            <p style={{fontSize:"27px",paddingTop:"10px",color:"blue"}}>{e.price}</p>
            <p style={{fontSize:"20px",paddingTop:"10px",display:"none"}}>{e.catagory}</p>
          </div>
        );
      })}
  </center>
</>

  );
}
